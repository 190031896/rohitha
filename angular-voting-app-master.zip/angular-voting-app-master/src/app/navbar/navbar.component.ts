import { Component } from '@angular/core';

@Component({
  selector: 'navbar',
  templateUrl: './navbar.view.html',
  styleUrls: ['./navbar.view.css'],
})
export class NavbarComponent { 


}